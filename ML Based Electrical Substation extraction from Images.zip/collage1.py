#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 28 00:22:34 2021

@author: ankith
"""

from PIL import Image, ImageDraw

import os
def get_paths():
  paths=[os.path.join('p_test_images/',f)for f in os.listdir('p_test_images/')]
  return paths
full_file_paths=get_paths()

full_file_paths.remove('p_test_images/.DS_Store')

sorted_images=['mosaic_test.jpg']

collage = Image.new("RGBA", (3750,3750), color=(255,255,255,255))
#lst = [100, 200, 300, 400, 500, 600, 700, 800, 900]
fold = 'p_test_images/'
#direc = 
c=0
for i in range(0,3750,750):
    for j in range(0,3750,750):
        if c == 0:
            file=fold+'mosaic_test'+'.jpg'
        else:
            file=fold+'mosaic_test'+str(c)+'.jpg'
        photo = Image.open(file).convert("RGBA")
        photo = photo.resize((750,750))        
        
        collage.paste(photo, (j,i))
        c+=1
collage.show()
collage.save("final_collage.jpg")